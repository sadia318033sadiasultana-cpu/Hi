import { useState } from "react";
import { generateImage, fastText, type AspectRatio } from "../services/gemini";
import { Loader2, Download, RefreshCw, Sparkles } from "lucide-react";
import { cn } from "../lib/utils";
import { ImageUpload } from "./ImageUpload";

const STYLES = [
  "None",
  "Photorealistic",
  "Anime",
  "Digital Art",
  "Oil Painting",
  "Watercolor",
  "Pixel Art",
  "Cyberpunk",
  "Steampunk",
  "3D Render",
  "Sketch",
];

export function Generate() {
  const [prompt, setPrompt] = useState("");
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>("1:1");
  const [style, setStyle] = useState("None");
  const [loading, setLoading] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [image, setImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);
  const [history, setHistory] = useState<Array<{ id: string; url: string; prompt: string; timestamp: number }>>([]);

  // Load history from local storage on mount
  useState(() => {
    try {
      const saved = localStorage.getItem("imageHistory");
      if (saved) {
        setHistory(JSON.parse(saved));
      }
    } catch (e) {
      console.error("Failed to load history", e);
    }
  });

  const addToHistory = (imageUrl: string, promptText: string) => {
    const newItem = {
      id: Date.now().toString(),
      url: imageUrl,
      prompt: promptText,
      timestamp: Date.now(),
    };
    const newHistory = [newItem, ...history].slice(0, 50); // Keep last 50
    setHistory(newHistory);
    localStorage.setItem("imageHistory", JSON.stringify(newHistory));
  };

  const handleImageSelect = (file: File) => {
    setFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const handleClear = () => {
    setFile(null);
    setPreviewUrl(null);
  };

  const handleEnhance = async () => {
    if (!prompt) return;
    setEnhancing(true);
    try {
      const enhanced = await fastText(`Enhance this image generation prompt to be more descriptive and artistic, keep it under 50 words: "${prompt}"`);
      setPrompt(enhanced.trim());
    } catch (err) {
      // Ignore error for enhancement
    } finally {
      setEnhancing(false);
    }
  };

  const handleGenerate = async () => {
    if (!prompt) return;
    setLoading(true);
    setError(null);
    try {
      let finalPrompt = prompt;
      
      // Easter egg: "143" triggers romantic scene with reference image
      if (prompt.trim() === "143" && file) {
        finalPrompt = "A romantic scene of the person in the reference image kissing a partner, passionate, cinematic lighting, high quality";
      } else if (style !== "None") {
        finalPrompt = `${prompt}, ${style} style`;
      }

      let result;
      if (file) {
        const reader = new FileReader();
        result = await new Promise<string>((resolve, reject) => {
          reader.onload = async () => {
            try {
              const base64 = (reader.result as string).split(",")[1];
              const mimeType = file.type;
              const img = await generateImage(finalPrompt, aspectRatio, base64, mimeType);
              resolve(img);
            } catch (e) {
              reject(e);
            }
          };
          reader.onerror = reject;
          reader.readAsDataURL(file);
        });
      } else {
        result = await generateImage(finalPrompt, aspectRatio);
      }
      
      setImage(result);
      addToHistory(result, finalPrompt);
    } catch (err) {
      setError("Failed to generate image. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Generate</h2>
        <div className="flex items-center gap-2 text-sm text-zinc-500">
          <span className="px-2 py-1 rounded-md bg-green-500/10 border border-green-500/20 text-green-400 font-medium text-xs">
            Unlimited Free
          </span>
          <span className="px-2 py-1 rounded-md bg-zinc-900 border border-zinc-800 font-mono">
            gemini-2.5-flash-image
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 flex flex-col gap-6">
          <div className="space-y-4">
            <label className="block text-sm font-medium text-zinc-400">
              Reference Image (Optional)
            </label>
            <ImageUpload
              onImageSelect={handleImageSelect}
              onClear={handleClear}
              previewUrl={previewUrl}
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium text-zinc-400">
                Prompt
              </label>
              <button
                onClick={handleEnhance}
                disabled={enhancing || !prompt}
                className="text-xs flex items-center gap-1 text-indigo-400 hover:text-indigo-300 disabled:opacity-50 transition-colors"
              >
                <Sparkles className="w-3 h-3" />
                {enhancing ? "Enhancing..." : "Enhance"}
              </button>
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe the image you want to create..."
              className="w-full h-32 px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none resize-none text-zinc-100 placeholder:text-zinc-600 transition-all"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="block text-sm font-medium text-zinc-400">
                Aspect Ratio
              </label>
              <select
                value={aspectRatio}
                onChange={(e) => setAspectRatio(e.target.value as AspectRatio)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 focus:border-indigo-500 outline-none text-zinc-100"
              >
                <option value="1:1">1:1 (Square)</option>
                <option value="3:4">3:4 (Portrait)</option>
                <option value="4:3">4:3 (Landscape)</option>
                <option value="9:16">9:16 (Story)</option>
                <option value="16:9">16:9 (Cinematic)</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-medium text-zinc-400">
                Style
              </label>
              <select
                value={style}
                onChange={(e) => setStyle(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-zinc-900 border border-zinc-800 focus:border-indigo-500 outline-none text-zinc-100"
              >
                {STYLES.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={loading || !prompt}
            className={cn(
              "w-full py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2",
              loading || !prompt
                ? "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20"
            )}
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <RefreshCw className="w-5 h-5" />
                Generate Image
              </>
            )}
          </button>
        </div>

        <div className="lg:col-span-2 bg-zinc-900/50 rounded-2xl border border-zinc-800/50 flex items-center justify-center min-h-[400px] relative overflow-hidden group">
          {image ? (
            <>
              <img
                src={image}
                alt={prompt}
                className="w-full h-full object-contain max-h-[600px]"
              />
              <div className="absolute top-4 right-4">
                <a
                  href={image}
                  download={`generated-${Date.now()}.png`}
                  className="p-2 bg-black/50 backdrop-blur-md rounded-lg text-white hover:bg-black/70 transition-colors block"
                  title="Download Image"
                >
                  <Download className="w-5 h-5" />
                </a>
              </div>
            </>
          ) : (
            <div className="text-center text-zinc-600">
              <div className="w-16 h-16 rounded-full bg-zinc-800/50 flex items-center justify-center mx-auto mb-4">
                <RefreshCw className="w-8 h-8 opacity-50" />
              </div>
              <p>Your generated image will appear here</p>
            </div>
          )}
          {image && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
              <a
                href={image}
                download={`generated-${Date.now()}.png`}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full shadow-lg transition-colors font-medium text-sm"
              >
                <Download className="w-4 h-4" />
                Download Image
              </a>
            </div>
          )}
          {error && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
              <div className="bg-zinc-900 border border-red-500/20 text-red-400 px-6 py-4 rounded-xl max-w-md text-center shadow-xl">
                <p className="mb-4">{error}</p>
                {error.includes("permission") ? (
                  <button
                    onClick={async () => {
                      try {
                        if (window.aistudio?.openSelectKey) {
                          await window.aistudio.openSelectKey();
                          setError(null);
                        } else {
                          alert("API Key selection is not available in this environment.");
                        }
                      } catch (e) {
                        console.error("Failed to open key selector", e);
                      }
                    }}
                    className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors text-sm font-medium border border-red-500/20"
                  >
                    Select Paid API Key
                  </button>
                ) : error.includes("sexually suggestive") || error.includes("harmful") ? (
                  <div className="flex flex-col gap-3">
                    <p className="text-sm text-zinc-400">
                      The AI model blocked this request due to safety guidelines. Please modify your prompt to be more appropriate.
                    </p>
                    <button
                      onClick={() => setError(null)}
                      className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg transition-colors text-sm"
                    >
                      I Understand
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setError(null)}
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg transition-colors text-sm"
                  >
                    Dismiss
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {history.length > 0 && (
        <div className="border-t border-zinc-800 pt-8">
          <h3 className="text-xl font-bold mb-4">History</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {history.map((item) => (
              <div 
                key={item.id} 
                className="group relative aspect-square rounded-lg overflow-hidden bg-zinc-900 border border-zinc-800 cursor-pointer hover:border-indigo-500 transition-colors"
                onClick={() => {
                  setImage(item.url);
                  setPrompt(item.prompt);
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
              >
                <img 
                  src={item.url} 
                  alt={item.prompt} 
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center p-2">
                  <p className="text-xs text-white text-center line-clamp-3">{item.prompt}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
