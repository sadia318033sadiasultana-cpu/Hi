import { useState } from "react";
import { editImage, fastText } from "../services/gemini";
import { Loader2, Download, Wand2, Sparkles } from "lucide-react";
import { cn } from "../lib/utils";
import { ImageUpload } from "./ImageUpload";

export function Edit() {
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [enhancing, setEnhancing] = useState(false);
  const [image, setImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);

  const handleImageSelect = (file: File) => {
    setFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const handleClear = () => {
    setFile(null);
    setPreviewUrl(null);
    setImage(null);
    setError(null);
  };

  const handleEnhance = async () => {
    if (!prompt) return;
    setEnhancing(true);
    try {
      const enhanced = await fastText(`Enhance this image editing instruction to be more precise and clear, keep it under 30 words: "${prompt}"`);
      setPrompt(enhanced.trim());
    } catch (err) {
      // Ignore error for enhancement
    } finally {
      setEnhancing(false);
    }
  };

  const handleEdit = async () => {
    if (!prompt || !file) return;
    setLoading(true);
    setError(null);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = reader.result as string;
        const mimeType = file.type;
        const result = await editImage(base64.split(",")[1], mimeType, prompt);
        setImage(result);
        setLoading(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError("Failed to edit image. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Edit</h2>
        <div className="flex items-center gap-2 text-sm text-zinc-500">
          <span className="px-2 py-1 rounded-md bg-green-500/10 border border-green-500/20 text-green-400 font-medium text-xs">
            Unlimited Free
          </span>
          <span className="px-2 py-1 rounded-md bg-zinc-900 border border-zinc-800 font-mono">
            gemini-2.5-flash-image
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 flex flex-col gap-6">
          <div className="space-y-4">
            <label className="block text-sm font-medium text-zinc-400">
              Upload Image
            </label>
            <ImageUpload
              onImageSelect={handleImageSelect}
              onClear={handleClear}
              previewUrl={previewUrl}
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium text-zinc-400">
                Prompt
              </label>
              <button
                onClick={handleEnhance}
                disabled={enhancing || !prompt}
                className="text-xs flex items-center gap-1 text-indigo-400 hover:text-indigo-300 disabled:opacity-50 transition-colors"
              >
                <Sparkles className="w-3 h-3" />
                {enhancing ? "Enhancing..." : "Enhance"}
              </button>
            </div>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Describe how to edit the image (e.g., 'Add a retro filter')..."
              className="w-full h-32 px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none resize-none text-zinc-100 placeholder:text-zinc-600 transition-all"
            />
          </div>

          <button
            onClick={handleEdit}
            disabled={loading || !prompt || !file}
            className={cn(
              "w-full py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2",
              loading || !prompt || !file
                ? "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20"
            )}
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Editing...
              </>
            ) : (
              <>
                <Wand2 className="w-5 h-5" />
                Edit Image
              </>
            )}
          </button>
        </div>

        <div className="lg:col-span-2 bg-zinc-900/50 rounded-2xl border border-zinc-800/50 flex items-center justify-center min-h-[400px] relative overflow-hidden group">
          {image ? (
            <>
              <img
                src={image}
                alt={prompt}
                className="w-full h-full object-contain max-h-[600px]"
              />
              <div className="absolute top-4 right-4">
                <a
                  href={image}
                  download={`edited-${Date.now()}.png`}
                  className="p-2 bg-black/50 backdrop-blur-md rounded-lg text-white hover:bg-black/70 transition-colors block"
                  title="Download Image"
                >
                  <Download className="w-5 h-5" />
                </a>
              </div>
            </>
          ) : (
            <div className="text-center text-zinc-600">
              <div className="w-16 h-16 rounded-full bg-zinc-800/50 flex items-center justify-center mx-auto mb-4">
                <Wand2 className="w-8 h-8 opacity-50" />
              </div>
              <p>Your edited image will appear here</p>
            </div>
          )}
          {image && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2">
              <a
                href={image}
                download={`edited-${Date.now()}.png`}
                className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full shadow-lg transition-colors font-medium text-sm"
              >
                <Download className="w-4 h-4" />
                Download Image
              </a>
            </div>
          )}
          {error && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
              <div className="bg-zinc-900 border border-red-500/20 text-red-400 px-6 py-4 rounded-xl max-w-md text-center shadow-xl">
                <p className="mb-4">{error}</p>
                {error.includes("permission") ? (
                  <button
                    onClick={async () => {
                      try {
                        if (window.aistudio?.openSelectKey) {
                          await window.aistudio.openSelectKey();
                          setError(null);
                        } else {
                          alert("API Key selection is not available in this environment.");
                        }
                      } catch (e) {
                        console.error("Failed to open key selector", e);
                      }
                    }}
                    className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors text-sm font-medium border border-red-500/20"
                  >
                    Select Paid API Key
                  </button>
                ) : error.includes("sexually suggestive") || error.includes("harmful") ? (
                  <div className="flex flex-col gap-3">
                    <p className="text-sm text-zinc-400">
                      The AI model blocked this request due to safety guidelines. Please modify your prompt to be more appropriate.
                    </p>
                    <button
                      onClick={() => setError(null)}
                      className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg transition-colors text-sm"
                    >
                      I Understand
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setError(null)}
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg transition-colors text-sm"
                  >
                    Dismiss
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
