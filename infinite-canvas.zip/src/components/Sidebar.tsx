import { ImagePlus, Wand2, ScanSearch, Zap, X } from "lucide-react";
import { cn } from "../lib/utils";

interface SidebarProps {
  currentView: "generate" | "edit" | "analyze";
  setView: (view: "generate" | "edit" | "analyze") => void;
  isOpen: boolean;
  onClose: () => void;
}

export function Sidebar({ currentView, setView, isOpen, onClose }: SidebarProps) {
  const items = [
    { id: "generate", label: "Generate", icon: ImagePlus },
    { id: "edit", label: "Edit", icon: Wand2 },
    { id: "analyze", label: "Analyze", icon: ScanSearch },
  ];

  if (!isOpen) return null;

  return (
    <aside className="w-64 border-r border-zinc-800 bg-zinc-900/50 p-6 flex flex-col gap-8 h-full relative">
      <button
        onClick={onClose}
        className="absolute top-4 right-4 p-1 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 rounded-md transition-colors"
        aria-label="Close sidebar"
      >
        <X className="w-5 h-5" />
      </button>

      <div className="flex items-center gap-3 px-2 mt-2">
        <div className="p-2 bg-indigo-500/10 rounded-lg">
          <Zap className="w-6 h-6 text-indigo-400" />
        </div>
        <h1 className="font-bold text-xl tracking-tight">Infinite Canvas</h1>
      </div>

      <nav className="flex flex-col gap-2">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id as any)}
            className={cn(
              "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200",
              currentView === item.id
                ? "bg-indigo-500/10 text-indigo-400 shadow-sm shadow-indigo-500/5"
                : "text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800/50"
            )}
          >
            <item.icon className="w-5 h-5" />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="mt-auto px-4 py-4 rounded-xl bg-zinc-900 border border-zinc-800">
        <p className="text-xs text-zinc-500 font-mono">
          Powered by Gemini 3 Pro & Flash
        </p>
      </div>
    </aside>
  );
}
