import { useState, useRef, type DragEvent, type ChangeEvent } from "react";
import { Upload, X } from "lucide-react";
import { cn } from "../lib/utils";

interface ImageUploadProps {
  onImageSelect: (file: File) => void;
  onClear: () => void;
  previewUrl: string | null;
}

export function ImageUpload({ onImageSelect, onClear, previewUrl }: ImageUploadProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      onImageSelect(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      onImageSelect(e.target.files[0]);
    }
  };

  return (
    <div
      className={cn(
        "relative border-2 border-dashed rounded-xl p-8 transition-colors flex flex-col items-center justify-center text-center min-h-[200px]",
        isDragging
          ? "border-indigo-500 bg-indigo-500/10"
          : "border-zinc-800 hover:border-zinc-700 bg-zinc-900/50"
      )}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      <input
        type="file"
        ref={inputRef}
        onChange={handleChange}
        accept="image/*"
        className="hidden"
      />

      {previewUrl ? (
        <div className="relative w-full h-full flex items-center justify-center">
          <img
            src={previewUrl}
            alt="Preview"
            className="max-h-[300px] object-contain rounded-lg shadow-lg"
          />
          <button
            onClick={(e) => {
              e.stopPropagation();
              onClear();
            }}
            className="absolute top-2 right-2 p-1 bg-black/50 rounded-full hover:bg-black/70 text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <div
          className="cursor-pointer flex flex-col items-center gap-4"
          onClick={() => inputRef.current?.click()}
        >
          <div className="p-4 bg-zinc-800 rounded-full">
            <Upload className="w-6 h-6 text-zinc-400" />
          </div>
          <div>
            <p className="font-medium text-zinc-300">
              Click to upload or drag and drop
            </p>
            <p className="text-sm text-zinc-500 mt-1">
              SVG, PNG, JPG or GIF (max. 800x400px)
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
