import { useState } from "react";
import { analyzeImage } from "../services/gemini";
import { Loader2, ScanSearch } from "lucide-react";
import { cn } from "../lib/utils";
import { ImageUpload } from "./ImageUpload";

export function Analyze() {
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [file, setFile] = useState<File | null>(null);

  const handleImageSelect = (file: File) => {
    setFile(file);
    setPreviewUrl(URL.createObjectURL(file));
  };

  const handleClear = () => {
    setFile(null);
    setPreviewUrl(null);
    setResult(null);
    setError(null);
  };

  const handleAnalyze = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    try {
      const reader = new FileReader();
      reader.onload = async () => {
        const base64 = reader.result as string;
        const mimeType = file.type;
        const analysis = await analyzeImage(base64.split(",")[1], mimeType, prompt || "Describe this image in detail.");
        setResult(analysis);
        setLoading(false);
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError("Failed to analyze image. Please try again.");
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col gap-8">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Analyze</h2>
        <div className="flex items-center gap-2 text-sm text-zinc-500">
          <span className="px-2 py-1 rounded-md bg-zinc-900 border border-zinc-800 font-mono">
            gemini-3.1-pro-preview
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 flex flex-col gap-6">
          <div className="space-y-4">
            <label className="block text-sm font-medium text-zinc-400">
              Upload Image
            </label>
            <ImageUpload
              onImageSelect={handleImageSelect}
              onClear={handleClear}
              previewUrl={previewUrl}
            />
          </div>

          <div className="space-y-4">
            <label className="block text-sm font-medium text-zinc-400">
              Prompt (Optional)
            </label>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Ask a question about the image (e.g., 'What is in this image?')..."
              className="w-full h-32 px-4 py-3 rounded-xl bg-zinc-900 border border-zinc-800 focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 outline-none resize-none text-zinc-100 placeholder:text-zinc-600 transition-all"
            />
          </div>

          <button
            onClick={handleAnalyze}
            disabled={loading || !file}
            className={cn(
              "w-full py-3 rounded-xl font-medium transition-all flex items-center justify-center gap-2",
              loading || !file
                ? "bg-zinc-800 text-zinc-500 cursor-not-allowed"
                : "bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-500/20"
            )}
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <ScanSearch className="w-5 h-5" />
                Analyze Image
              </>
            )}
          </button>
        </div>

        <div className="lg:col-span-2 bg-zinc-900/50 rounded-2xl border border-zinc-800/50 flex flex-col min-h-[400px] relative overflow-hidden p-6">
          {result ? (
            <div className="prose prose-invert max-w-none">
              <h3 className="text-xl font-bold mb-4 text-zinc-100">Analysis Result</h3>
              <p className="text-zinc-300 whitespace-pre-wrap leading-relaxed">{result}</p>
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center text-center text-zinc-600">
              <div>
                <div className="w-16 h-16 rounded-full bg-zinc-800/50 flex items-center justify-center mx-auto mb-4">
                  <ScanSearch className="w-8 h-8 opacity-50" />
                </div>
                <p>Your analysis will appear here</p>
              </div>
            </div>
          )}
          {error && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
              <div className="bg-zinc-900 border border-red-500/20 text-red-400 px-6 py-4 rounded-xl max-w-md text-center shadow-xl">
                <p className="mb-4">{error}</p>
                {error.includes("permission") && (
                  <button
                    onClick={async () => {
                      try {
                        if (window.aistudio?.openSelectKey) {
                          await window.aistudio.openSelectKey();
                          setError(null);
                        } else {
                          alert("API Key selection is not available in this environment.");
                        }
                      } catch (e) {
                        console.error("Failed to open key selector", e);
                      }
                    }}
                    className="px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors text-sm font-medium border border-red-500/20"
                  >
                    Select Paid API Key
                  </button>
                )}
                {!error.includes("permission") && (
                  <button
                    onClick={() => setError(null)}
                    className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-lg transition-colors text-sm"
                  >
                    Dismiss
                  </button>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
