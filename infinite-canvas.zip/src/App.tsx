import { useState } from "react";
import { Sidebar } from "./components/Sidebar";
import { Generate } from "./components/Generate";
import { Edit } from "./components/Edit";
import { Analyze } from "./components/Analyze";
import { Menu } from "lucide-react";

export default function App() {
  const [view, setView] = useState<"generate" | "edit" | "analyze">("generate");
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  return (
    <div className="flex h-screen bg-zinc-950 text-zinc-100 font-sans overflow-hidden relative">
      <Sidebar 
        currentView={view} 
        setView={setView} 
        isOpen={isSidebarOpen} 
        onClose={() => setIsSidebarOpen(false)} 
      />
      
      {!isSidebarOpen && (
        <button
          onClick={() => setIsSidebarOpen(true)}
          className="absolute top-4 left-4 z-50 p-2 bg-zinc-900/80 backdrop-blur-sm border border-zinc-800 rounded-lg text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 transition-colors"
        >
          <Menu className="w-6 h-6" />
        </button>
      )}

      <main className="flex-1 overflow-y-auto p-8">
        <div className="max-w-6xl mx-auto">
          {view === "generate" && <Generate />}
          {view === "edit" && <Edit />}
          {view === "analyze" && <Analyze />}
        </div>
      </main>
    </div>
  );
}
