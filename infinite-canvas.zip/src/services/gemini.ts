import { GoogleGenAI } from "@google/genai";

// Helper to get the AI client, ensuring we use the latest key
function getClient(): GoogleGenAI {
  return new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
}

export type AspectRatio = "1:1" | "2:3" | "3:2" | "3:4" | "4:3" | "9:16" | "16:9" | "21:9";
export type ImageSize = "1K" | "2K" | "4K";

export async function generateImage(
  prompt: string,
  aspectRatio: AspectRatio = "1:1",
  base64Image?: string,
  mimeType?: string
): Promise<string> {
  try {
    const ai = getClient();
    const parts: any[] = [{ text: prompt }];
    
    if (base64Image && mimeType) {
      parts.push({
        inlineData: {
          data: base64Image,
          mimeType: mimeType,
        },
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: parts,
      },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio,
        },
      },
    });

    // Extract image from response
    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }
    
    // If no image, check for text response (e.g. safety refusal)
    const textResponse = response.text;
    if (textResponse) {
      throw new Error(textResponse);
    }

    throw new Error("No image generated");
  } catch (error) {
    console.error("Generate Image Error:", error);
    throw error;
  }
}

export async function editImage(
  base64Image: string,
  mimeType: string,
  prompt: string
): Promise<string> {
  try {
    const ai = getClient();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-image",
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          { text: prompt },
        ],
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
      }
    }

    // If no image, check for text response (e.g. safety refusal)
    const textResponse = response.text;
    if (textResponse) {
      throw new Error(textResponse);
    }

    throw new Error("No image generated from edit");
  } catch (error) {
    console.error("Edit Image Error:", error);
    throw error;
  }
}

export async function analyzeImage(
  base64Image: string,
  mimeType: string,
  prompt: string = "Describe this image in detail."
): Promise<string> {
  try {
    const ai = getClient();
    const response = await ai.models.generateContent({
      model: "gemini-3.1-pro-preview",
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Image,
              mimeType: mimeType,
            },
          },
          { text: prompt },
        ],
      },
    });

    return response.text || "No analysis available.";
  } catch (error) {
    console.error("Analyze Image Error:", error);
    throw error;
  }
}

export async function fastText(prompt: string): Promise<string> {
  try {
    const ai = getClient();
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-lite",
      contents: {
        parts: [{ text: prompt }],
      },
    });
    return response.text || "";
  } catch (error) {
    console.error("Fast Text Error:", error);
    throw error;
  }
}
